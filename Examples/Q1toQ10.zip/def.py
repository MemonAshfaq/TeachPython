def print_country_name(country):
    print (country)

def add (a, b):
    return a+b

country_list = ["America", "Japan", "Canada", "Singapore"]

for country in country_list:
    print_country_name(country)

sum = add(5,2)
print (sum)
sum = add(400,345)
print (sum)




